package com.footprint.controller;


import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.footprint.entity.User;
import com.footprint.service.IUserService;
import com.footprint.util.HttpClientUtil;
import com.footprint.util.UserConstantInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xiang
 * @since 2022-06-10
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    IUserService iUserService;

    /**
     * 小程序登录
     * @param code
     * @param userHead
     * @param userName
     * @param request
     * @return
     */
    @RequestMapping("/login")
    public Map<String, Object> user_login(
            @RequestParam("code") String code,
            @RequestParam("userHead") String userHead,
            @RequestParam("userName") String userName,
            HttpServletRequest request
    ){
        HttpSession session = request.getSession();
        // 配置请求参数
        Map<String, String> param = new HashMap<>();
        param.put("appid", UserConstantInterface.WX_LOGIN_APPID);
        param.put("secret", UserConstantInterface.WX_LOGIN_SECRET);
        param.put("js_code", code);
        param.put("grant_type", UserConstantInterface.WX_LOGIN_GRANT_TYPE);
        // 发送请求
        String wxResult = HttpClientUtil.doGet(UserConstantInterface.WX_LOGIN_URL, param);
        JSONObject jsonObject = JSONObject.parseObject(wxResult);
        // 获取参数返回的
        String session_key = jsonObject.get("session_key").toString();
        String open_id = jsonObject.get("openid").toString();
        Map<String,Object> returnData = MapUtil.newHashMap();
        returnData.putAll(param);
        // 根据返回的user实体类，判断用户是否是新用户，不是的话，更新最新登录时间，是的话，将用户信息存到数据库
        LambdaQueryWrapper<User> queryWrapper = Wrappers.lambdaQuery();
        queryWrapper.eq(User::getOpenid,open_id);
        User user = iUserService.getOne(queryWrapper);
        if(user == null){
            User insert_user = new User();
            insert_user.setHead(userHead);
            insert_user.setName(userName);
            insert_user.setOpenid(open_id);
            insert_user.setTime(new Date());
            // 添加到数据库
            boolean i  = iUserService.save(insert_user);
            User newuser = iUserService.getOne(queryWrapper);
            returnData.put("phone",newuser.getPhone());
            returnData.put("userId",newuser.getId());
            returnData.put("type",newuser.getType());
            session.setAttribute("qtuser",newuser);
        }else{
            User insert_user = new User();
            insert_user.setHead(userHead);
            insert_user.setName(userName);
            insert_user.setId(user.getId());
            boolean i  = iUserService.updateById(insert_user);
            returnData.put("userId",user.getId());
            returnData.put("type",user.getType());
            returnData.put("phone",user.getPhone());
            session.setAttribute("qtuser",user);
        }
        returnData.put("avatarUrl",userHead);
        returnData.put("nickName",userName);
        returnData.put("sessionid",session.getId());
        returnData.put("session_key",session_key);
        return returnData;
    }


}
