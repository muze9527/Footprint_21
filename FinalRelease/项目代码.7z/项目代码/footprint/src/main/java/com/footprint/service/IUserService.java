package com.footprint.service;

import com.footprint.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xiang
 * @since 2022-06-10
 */
public interface IUserService extends IService<User> {

}
