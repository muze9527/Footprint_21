package com.footprint.service.impl;

import com.footprint.entity.Footprintedit;
import com.footprint.mapper.FootprinteditMapper;
import com.footprint.service.IFootprinteditService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xiang
 * @since 2022-06-10
 */
@Service
public class FootprinteditServiceImpl extends ServiceImpl<FootprinteditMapper, Footprintedit> implements IFootprinteditService {

}
