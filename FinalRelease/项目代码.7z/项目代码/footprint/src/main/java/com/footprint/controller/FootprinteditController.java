package com.footprint.controller;


import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.footprint.common.RetResponse;
import com.footprint.common.RetResult;
import com.footprint.entity.Footprintedit;
import com.footprint.service.IFootprinteditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xiang
 * @since 2022-06-10
 */
@RestController
@RequestMapping("/footprintedit")
public class FootprinteditController {


    @Autowired
    IFootprinteditService iFootprinteditService;

    @PostMapping("/add")
    public RetResult add(@RequestBody Footprintedit footprintedit){
        RetResponse res = null;
        boolean one = iFootprinteditService.save(footprintedit);
        if(one==true){
            return RetResponse.makeOKRsp("success");
        }else{
            return RetResponse.makeErrRsp("error");
        }
    }


    @RequestMapping("/listByIndex")
    public RetResult<List<Footprintedit>> listByIndex(){
        LambdaQueryWrapper<Footprintedit> queryWrapper =  Wrappers.lambdaQuery();
        queryWrapper.eq(Footprintedit::getState,1);
        List<Footprintedit> Page = iFootprinteditService.list(queryWrapper);
        return RetResponse.makeOKRsp(Page);
    }

    @RequestMapping("/listByFid")
    public RetResult<List<Footprintedit>> listByFid(Integer fid){
        LambdaQueryWrapper<Footprintedit> queryWrapper =  Wrappers.lambdaQuery();
        queryWrapper.eq(Footprintedit::getFid,fid);
        List<Footprintedit> Page = iFootprinteditService.list(queryWrapper);
        return RetResponse.makeOKRsp(Page);
    }

    @RequestMapping("/getById")
    public RetResult<Footprintedit> getById(Integer id){
        Footprintedit footprintedit = iFootprinteditService.getById(id);
        return RetResponse.makeOKRsp(footprintedit);
    }
}
