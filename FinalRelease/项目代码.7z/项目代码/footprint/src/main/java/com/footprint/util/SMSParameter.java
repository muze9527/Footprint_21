package com.footprint.util;

import cn.hutool.json.JSONException;
import com.github.qcloudsms.SmsSingleSender;
import com.github.qcloudsms.SmsSingleSenderResult;

import javax.xml.ws.http.HTTPException;
import java.io.IOException;


public class SMSParameter {
    // 短信应用 SDK AppID，SDK AppID 以1400开头
    private static int appId = 1400579949;
    // 短信应用SDK AppKey
    private static String appKey = "f6eaea1da644fe9c949d139b99763946";

    // 短信模板ID，需要在短信控制台中申请，我们查看自己的短信模板ID即可
    private static int templateId = 1146575;
    // 签名，签名参数使用的是`签名内容`，而不是`签名ID`，真实的签名需要在短信控制台申请，这里按自己的来修改就好
    private static String smsSign = "餐剧";

    public static SmsSingleSenderResult sendMessage(String phoneNumber,String name,String type){
        SmsSingleSenderResult result = null;
        try {
            String[] params = {name, type};
            SmsSingleSender ssender = new SmsSingleSender(appId, appKey);
            result = ssender.sendWithParam("86", phoneNumber, templateId, params, smsSign, "", "");

        } catch (HTTPException e) {
            // HTTP响应码错误
            e.printStackTrace();
        } catch (JSONException e) {
            // json解析错误
            e.printStackTrace();
        } catch (IOException e) {
            // 网络IO错误
            e.printStackTrace();
        } catch (com.github.qcloudsms.httpclient.HTTPException e) {
            e.printStackTrace();
        }
        return result;
    }

}
