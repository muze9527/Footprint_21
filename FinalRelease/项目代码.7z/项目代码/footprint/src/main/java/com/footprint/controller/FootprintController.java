package com.footprint.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.footprint.common.RetResponse;
import com.footprint.common.RetResult;
import com.footprint.entity.Footprint;
import com.footprint.entity.Footprintedit;
import com.footprint.service.IFootprintService;
import com.footprint.service.IFootprinteditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xiang
 * @since 2022-06-10
 */
@RestController
@RequestMapping("/footprint")
public class FootprintController {

    @Autowired
    IFootprintService iFootprintService;

    @Autowired
    IFootprinteditService iFootprinteditService;

    @PostMapping("/add")
    public RetResult add(@RequestBody Footprint footprint){
        RetResponse res = null;
        boolean one = iFootprintService.save(footprint);
        LambdaQueryWrapper<Footprintedit> queryWrapper =  Wrappers.lambdaQuery();
        queryWrapper.eq(Footprintedit::getState,1);
        List<Footprintedit> footprintedits = iFootprinteditService.list(queryWrapper);
        for(Footprintedit footprintedit : footprintedits){
            footprintedit.setFid(footprint.getId());
            footprintedit.setState(2);
            iFootprinteditService.updateById(footprintedit);
        }
        if(one==true){
            return RetResponse.makeOKRsp("success");
        }else{
            return RetResponse.makeErrRsp("error");
        }
    }

    @RequestMapping("/listByBack")
    public RetResult<List<Footprint>> listByBack(){
        List<Footprint> Page = iFootprintService.list();
        return RetResponse.makeOKRsp(Page);
    }

}
