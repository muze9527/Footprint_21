package com.footprint.util;

public class testMessage {

    public static void main(String[] args) {


    }


}
