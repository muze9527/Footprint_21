package com.footprint.service;

import com.footprint.entity.Footprint;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xiang
 * @since 2022-06-10
 */
public interface IFootprintService extends IService<Footprint> {

}
