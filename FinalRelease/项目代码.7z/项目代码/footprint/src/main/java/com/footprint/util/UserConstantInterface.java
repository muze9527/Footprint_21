package com.footprint.util;

public interface UserConstantInterface {
    // 请求的网址
    public static final String WX_LOGIN_URL = "https://api.weixin.qq.com/sns/jscode2session";
    // 你的appid
    public static final String WX_LOGIN_APPID = "wx9d76c1b09dbf6e73";
    // 你的密匙
    public static final String WX_LOGIN_SECRET = "e54e4979915aa4d353a22e1664091c20";
    // 固定参数
    public static final String WX_LOGIN_GRANT_TYPE = "authorization_code";
}
