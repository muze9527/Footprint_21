package com.footprint.common;

public class FileTables {

    private static final String rotationchart = "rotationchart";

}
