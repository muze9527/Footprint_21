<template>
	<view class="content">
		<!-- 在map标签绑定经纬度和标记点数组，以及连线数组 -->
		<map id="maps" :latitude="latitude" :longitude="longitude" :markers="markers" :polyline="polylines" scale="10" show-location="true"></map>
	</view>
</template>

<script>
	import amap from '@/libs/amap-uni.js';
	export default {
		data() {
			return {
				amapPlugin: null,
				key: '3f11789154f106ea0e0fc5dfc1134107	',//高德地图key
				latitude: '',//纬度
				longitude: '',//经度
				markers:[],//标记点数组
				polylines:[]//连续数组
			}
		},
		onReady() {
			//调用的函数放到onReady里面
			this.getlocal();
			this.test();
			this.amapPlugin = new amap.AMapWX({
				key: this.key
			});
		},
		methods: {
			//地图标记点;   具体的属性可以看看官网的说明
			test(){
				var that = this;
				//地图标记点连线静态数据赋值;
				// 可以理解成下面polylines里面的一个对象为一条线，每一条线都是独立的，可以设置不同的连续颜色
				//points[]里面是从第一个对象连到最后一个对象的经纬度成一条线
				that.polylines = [{
					points: [{
							latitude: 23.043594,
							longitude: 113.160704
						},
						{
							latitude: 23.036344,
							longitude: 113.160704
						},
						{
							latitude: 23.03528,
							longitude: 113.149565
						},
						{
							latitude: 23.03794,
							longitude: 113.138498
						},
						{
							latitude: 23.049247,
							longitude: 113.145684
						}
					],
					color: "#0091ff",
					width: 4
				}];
				//地图标记点静态数据赋值;
				//标记点和连线的意思差不多，标记点的数组是单纯将markers数组中的对象的经纬度通过图片的方式标记出来（图片可以自定义）
				that.markers = [{
						id:0,
						latitude: 23.043594,
						longitude: 113.160704,
						iconPath: '../../static/icon/didian.png',
					    width: 33,
					    height: 33
					},
					{
						id:1,
						latitude: 23.036344,
						longitude: 113.160704,
						iconPath: '../../static/icon/didian.png',
						width: 33,
						height: 33
					},
					{
						id:2,
						latitude: 23.03528,
						longitude: 113.149565,
						iconPath: '../../static/icon/didian.png',
						width: 33,
						height: 33
					},
					{
						id:3,
						latitude: 23.03794,
						longitude: 113.138498,
						iconPath: '../../static/icon/didian.png',
						width: 33,
						height: 33
					},
					{
						id:5,
						latitude: 23.049247,
						longitude: 113.145684,
						iconPath: '../../static/icon/didian.png',
						width: 33,
						height: 33
					}
				];
			},
			//定位方法;获取当前的经纬度，也可以通过经纬度来获取当前的地理位置，比如：xx省、xx市、xx镇
			getlocal: function() {
				var that = this;
				uni.getLocation({
					type: 'wgs84',
					geocode:true,//设置该参数为true可直接获取经纬度及城市信息
					success: function (res) {
						that.latitude = res.latitude
						that.longitude = res.longitude
					},
					fail: function () {
						uni.showToast({
							title: '获取地址失败，将导致部分功能不可用',
							icon:'none'
						});
					}
				});
			},
		}
	}
</script>

<style scoped lang="scss">
	.content {
		position: absolute;
		width: 100%;
		height: 100%;

		#maps {
			width: 100%;
			height: 100%;
		}
	}
</style>