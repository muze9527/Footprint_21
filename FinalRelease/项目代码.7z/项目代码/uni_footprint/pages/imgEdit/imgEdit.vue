<template>
	<view>
		<label>{{name}}</label>
		<view v-for="(item,idex) in imgList">
			<img :src="item.url" alt="" style="width: 100%;">
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				imgList:[],
				name:''
			}
		},
		onLoad(option) {
			var that = this;
			uni.request({
				url: getApp().globalData.url + "/footprintedit/getById?id="+option.id,
				method: "GET",
				contentType: "application/json;charset=utf-8",
				success: (res) => {
					var data = res.data.data
					
					var imgList = JSON.parse(data.url)
					console.log(imgList)
					for(var img in imgList){
						imgList[img].url = getApp().globalData.url + "/" + imgList[img].url 
					}
					that.imgList = imgList
					that.name = data.JSON
					console.log(that.imgList)
				}
			})
			
			
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
