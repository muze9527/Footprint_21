<template>
	<view class="content">
		<view class="row b-b">
			<text class="tit">地点名称</text>
			<input class="input" type="text" v-model="name" placeholder="请输入地点名称" placeholder-class="placeholder" />
		</view>
		
		 <view class="row b-b">
			<text class="tit">经度</text>
			<input class="input" type="text" v-model="latitude" placeholder="请输入地点名称" placeholder-class="placeholder" disabled="true"/>
		 </view>
		 
		 <view class="row b-b">
			<text class="tit">纬度</text>
			<input class="input" type="text" v-model="longitude" placeholder="请输入地点名称" placeholder-class="placeholder" />
		 </view>
		<view class="b-b">
			<view class="button">
				<button @click="xqChoose" value="请选择文件" class="imgButton">添加图片</button>
			</view>
			<view class="img" v-for="xqImgPath in xqImgPaths">
				<image class="img_img" :src="xqImgPath"></image>
			</view>
		</view>

		<button class="add-btn" @click="confirm">提交</button>
	</view>
	
	
</template>

<script>
	export default {
		data() {
			return {
				imgPaths:[],
				xqImgPaths:[],
				dataImgPaths:[],
				dataXqImgPaths:[],
				name:'',
				userId:'',
				id:'',
				latitude:'',
				longitude:''
			}
		},
		onLoad(option){
			console.log(option)
			var _this = this
			_this.latitude = option.latitude
			_this.longitude = option.longitude
			uni.checkSession({
				success: (res) => {
					const value = uni.getStorageSync("userInfo");
					if (value != null) {
						_this.userId = value.data.userId;
					}
				}
			})
		},
		methods: {
			
			choose(e){
				var me = this;
				uni.chooseImage({
					count: 1, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: function (res) {
						if(me.imgPaths.length>1){
							uni.showModal({
								content: '最多选择一张封面图',
								showCancel: false,
							});
						}else{
							me.imgPaths = res.tempFilePaths;
							uni.uploadFile({
								url: getApp().globalData.url + '/demo/file/uploadImg',
								method: "POST",
								filePath: me.imgPaths[0],
								name: 'uploadFile',
								formData: {
									'user': 'test'
								},
								success: (uploadFileRes) => {
									console.log(uploadFileRes.data);
									me.dataImgPaths = uploadFileRes.data
								}
							});
						}
					}
				});
			},
			
			xqChoose(e){
				var me = this;
				me.dataXqImgPaths.length = 0
				uni.chooseImage({
					count: 5, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: function (res) {
						if(me.xqImgPaths.length>5){
							uni.showModal({
								content: '最多选择五张详情图',
								showCancel: false,
							});
						}else{
							me.xqImgPaths = res.tempFilePaths;
							for(var i = 0;i<me.xqImgPaths.length;i++){
								uni.uploadFile({
									url: getApp().globalData.url + '/file/uploadImg',
									method: "POST",
									filePath: me.xqImgPaths[i],
									name: 'uploadFile',
									formData: {
										'user': 'test'
									},
									success: (uploadFileRes) => {
										var f = {};
										f.url = uploadFileRes.data
										me.dataXqImgPaths.push(f); 
									},
									fail:(res) => {
										console.log(res)
									}
								});
							}
						}
					}
				});
			},
			confirm:function(){
				var data = {}
				data.name = this.name;
				data.latitude = this.latitude;
				data.longitude = this.longitude;
				data.time = new Date();
				data.url = JSON.stringify(this.dataXqImgPaths)
				data.state = 1;
				uni.request({
					url: getApp().globalData.url + '/footprintedit/add',
					method: "POST",
					async:true,
					data:JSON.stringify(data),
					success:function(res){
						if(res.data.data == "success") {
							uni.showModal({
								content: '提交成功',
								showCancel: false,
								success: (res) => {
									if(res.confirm) {  
										uni.navigateBack()
									}
								} 
							});
						} else {
							uni.showModal({
								content: '网络异常请联系客服',
								showCancel: false,
								success: (res) => {
									// if(res.confirm) {  
									// 	uni.navigateBack()
									// }
								} 
							});
						}
					},
					error:function(){
						uni.showModal({
							content: '网络异常请联系客服',
							showCancel: false,
							success: (res) => {
								if(res.confirm) {  
									uni.navigateBack()
								}
							} 
						});
					}
				})
			}
		
			
		}
	}
	
</script>

<style>
 page {
        padding-top: 16upx;
    }
	.button{
		width: 90%;
		margin-left: 5%;	
	}
	.imgButton{
		height: 30px;
		background: #1296db;
		border: 1px solid #1296db;
		font-size: 15px;
		line-height: 30px;
		color: white;
	}
    .row {
        display: flex;
        align-items: center;
        position: relative;
        padding: 0 30upx;
        height: 110upx;
        background: #fff;
		}
        .tit {
            flex-shrink: 0;
            width: 120upx;
            font-size: 15px;
 
        }
 
        .input {
            flex: 1;
            font-size: 30upx;
 
        }
 
        .icon-shouhuodizhi {
            font-size: 36upx;
 
        }
    
 
    .add-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 690upx;
        height: 80upx;
        margin: 60upx auto;
        background-color: rgb(28, 42, 134);
        color: #fff;
 
        border-radius: 10upx;
        box-shadow: 1px 2px 5px rgba(28, 42, 134, 0.4);
    }

</style>
