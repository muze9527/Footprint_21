<template>
    <view class="login">
        <view class="button" @click="login">点击授权登录</view>
    </view>
</template>

<script>
    export default {
        data() {
            return {
                title: 'Hello'
            }
        },
        onLoad() {

        },
        methods: {
            login() {
				var that = this;
				getApp().login();
				// const value = uni.getStorageSync("userInfo");
				// console.log(value)
				// uni.getStorage({
				// 	key: 'userInfo',
				// 	success: function(res) {
				// 		// that.user = uni.getStorageSync("userInfo");
				// 		console.log(res)
				// 		if(res != null&&res !=''){
				// 			uni.navigateTo({
				// 				url: '/pages/checkrole/checkrole',
				// 			});
				// 		}
				// 	}
				// });
            },
        }
    }
</script>

<style lang="scss">
    .top_item {
        display: flex;
        margin-top: 40rpx;
        margin-left: 32rpx;
        margin-right: 32rpx;
        justify-content: space-between;
    }

    .input-item {
        display: flex;
        margin-left: 32rpx;
        margin-right: 32rpx;
        height: 50px;
        align-items: center;
        border-bottom: 1px solid #efeff4;
        margin-bottom: 20rpx;

        .title-content {
            display: flex;
            justify-content: flex-start;
            align-items: center;

            .title {
                font-size: 18px;
            }
        }

        .input {
            flex: 1;
        }
    }

    .button {
        height: 50px;
        line-height: 50px;
        margin-top: 60rpx;
        margin-left: 32rpx;
        margin-right: 32rpx;
        border-radius: 50rpx;
        font-size: 20px;
        background-color: green;
        color: #FFFFFF;
        text-align: center;
    }
</style>
