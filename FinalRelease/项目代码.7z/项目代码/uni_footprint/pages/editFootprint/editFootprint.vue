<template>
		<!-- /**  
	 * map 用到的属性 
	 * @param width map宽度
	 * @param height map高度
	 * @param latitude 中心纬度
	 * @param longitude 中心经度
	 * @param scale 缩放级别，取值范围为5-18
	 * @param markers 标记点 
	 * @param show-location 显示带有方向的当前定位点
	 * @param markertap 点击标记点时触发
	 * */ -->
	<view class="content">
		<map class="map" id="map" :latitude="latitude" :longitude="longitude" scale="18" show-location="true" :markers="markers"
		 @markertap="markertap" :polyline="polylines"></map>
	</view>
	
</template>

<script>
	import amap from '@/libs/amap-uni.js';
	export default {
		data() {
			return {
				amapPlugin: null,
				key: '3f11789154f106ea0e0fc5dfc1134107	',//高德地图key
				
				markers: [
					
				],
				polylines : [{
					points: [],
					color: "#0091ff",
					width: 4
				}],
				poisdatas: [],
				latitude:'',
				longitude: '',
				userId:'',
				threeType:[],
				moreShow:false,
				typeList:[],
				isShow:false,
				sreachList:[],
				initLatitude:'',
				initLongitude: '',
				phoneShow:false,
				name:'',
			}
		},
		onLoad(option) {
			var that = this;
			
			uni.getLocation({
				type: 'wgs84',
				geocode:true,//设置该参数为true可直接获取经纬度及城市信息
				success: function (res) {
					that.latitude = res.latitude
					that.longitude = res.longitude
					that.initLatitude = res.latitude
					that.initLongitude = res.longitude
				},
				fail: function () {
					uni.showToast({
						title: '获取地址失败，将导致部分功能不可用',
						icon:'none'
					});
				}
			});
			
			uni.request({
				url: getApp().globalData.url + "/footprintedit/listByFid?fid="+option.id,
				method: "GET",
				contentType: "application/json;charset=utf-8",
				success: (res) => {
					var data = res.data.data
					for(var item in data){
						var marker = {};
						marker.iconPath = "../../static/icon/didian.png"
						marker.id = data[item].id
						marker.latitude = data[item].latitude
						marker.longitude = data[item].longitude
						marker.width = 33
						marker.height = 33
						that.markers.push(marker)
						that.destination = data[item].longitude + "," + data[item].latitude
						
						var point = {}
						point.latitude = data[item].latitude
						point.longitude = data[item].longitude
						that.polylines[0].points.push(point)
					}
					
				}
			})
			that.amapPlugin = new amap.AMapWX({
				key: that.key
			});
			
		},
		methods: {
			submit(){
				var that = this
				var data = {}
				data.name = that.name;
				data.time = new Date();
				uni.request({
					url: getApp().globalData.url + '/footprint/add',
					method: "POST",
					async:true,
					data:JSON.stringify(data),
					success:function(res){
						if(res.data.data == "success") {
							uni.showModal({
								content: '提交成功',
								showCancel: false,
								success: (res) => {
									that.phoneShow = false;
								} 
							});
						} else {
							uni.showModal({
								content: '网络异常请联系客服',
								showCancel: false,
								success: (res) => {
									// if(res.confirm) {  
									// 	uni.navigateBack()
									// }
								} 
							});
						}
					},
					error:function(){
						uni.showModal({
							content: '网络异常请联系客服',
							showCancel: false,
							success: (res) => {
								if(res.confirm) {  
									uni.navigateBack()
								}
							} 
						});
					}
				})
			},
			commit(){
				this.phoneShow = true
			},
			
			toLocation:function(latitude,longitude){
				this.latitude = latitude
				this.longitude = longitude
				this.isShow=false
			},

			jump(path, query) {
				this.$Router.push({
					path: path,
					query: {item:JSON.stringify(query)}
				});
			},
			//点击地图标点时触发
			markertap: function(e) {
				console.log(e)
				console.log(e.detail.markerId)
				uni.navigateTo({
					url:'../imgEdit/imgEdit?id='+e.detail.markerId,
				});
			},
			changeMarkerColor: function(data, i) {
				var that = this;
				var markers = [];
				for (var j = 0; j < data.length; j++) {
					if (j == i) {
						data[j].iconPath = ""; //如：..­/..­/img/marker_checked.png
					} else {
						data[j].iconPath = ""; //如：..­/..­/img/marker.png
					}
					markers.push(data[j]);
				}
				that.marker = markers;
			}
		}
	}
	
</script>

<style lang="scss">
	.submit{
		width: 110px;
		height: 30px;
		line-height: 30px;
		font-size: 15px;
	}
	.popup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.phonePopup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.phone-popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.kfView{
		margin-top:15px;
	}
	.cancelBtn {
		width: 90%;
		margin-bottom: 5px;
		margin-top: 1%;
		background: #1296db;
		color: white;
		height: 30px;
		line-height: 30px;
		border-radius: 5px;
	}
	.tcIconImgView{
		widht:30%;
		margin-top:5px;
	}
	.tcIconImg{
		width: 20px;//图标icon 宽度
		height: 20px;
	}
	.tcIconLable{
		margin-left:5px;
	}
	.phonePopup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.phone-popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.userback {
		height: 126px;
		background-size: 100%;
		text-align: center;
		margin-top: 10px;
	}
	.iconLable{
	}
	.icon{
		padding:2px;
	}
	.iconLable{
		font-size:12px;
	}
	.iconImg{
		width: 18px;//图标icon 宽度
		height: 18px;
	}
	.icon{
		position: absolute;
		bottom: 0px;
		height: 50px;
		width: 160px;
		background:transparent;
		border-radius: 10px;
	}
	.sreach{
		position: absolute;
		top: 2px;
		left: 25%;
		line-height: 40px;
		padding-left: 10px;
		height: 28px;
		width: 200px;
		background:white;
		border-radius: 10px;
	}
	.sreachList{
		overflow:auto;
		position: absolute;
		background: white;
		top: 35px;
		left: 25%;
		line-height: 40px;
		padding-left: 10px;
		width: 200px;
		height: 100px;
		background:white;
		border-radius: 10px;
	}
	.sreachList::-webkit-scrollbar { 
		width: 4px; /*高宽分别对应横竖滚动条的尺寸*/
		height:0px;
	}
	/*定义滚动条轨道 内阴影+圆角*/
		.sreachList::-webkit-scrollbar-track
		{
			// -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
			border-radius: 10px;
			background-color: #fff;
		}
		 
		/*定义滑块 内阴影+圆角*/
		.sreachList::-webkit-scrollbar-thumb
		{
			border-radius: 10px;
			-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
			background-color: #555;
		}
	map{
		height: 850px;
		width: 100%;
	}
	.iconImgView{
		margin-top:3px;
	}
</style>
