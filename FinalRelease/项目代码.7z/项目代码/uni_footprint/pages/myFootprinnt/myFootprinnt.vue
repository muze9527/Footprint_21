<template>
	<view>
		<view class="top">
			<label class="title">我的足迹</label>
		</view>
		<view v-for="(item,index) in songList" :key="index">
			<view class="songList" @click="toZj(item.id)">
				<view class="left">
					<label>{{index+1}}</label>
				</view>
				<view class="content" >
						<label>{{item.name}}</label>
				</view>
				<view class="rigt">
					<img src="../../static/icon/you.png" alt="">
				</view>
			</view>
		</view>
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				type:'',
				id:'',
				songList:'',
				songListShow:false,
				mySongList:[],
				mySongListId:'',
				musicId:''
			}
		},
		onLoad(option) {
			uni.request({
				url: getApp().globalData.url + "/footprint/listByBack",
				method: "GET",
				contentType: "application/json;charset=utf-8",
				success: (res) => {
					var data = res.data.data
					
					console.log(data)
					this.songList = data
				}
			})
		},
		methods: {
			toZj(id){
				uni.navigateTo({
					url:'../editFootprint/editFootprint?id='+id,
				});
			},
		}
	}
</script>

<style lang="scss">
	.caozuo_img{
		img{
			width: 20px;
			height: 20px;
			margin-top: 10px;
		}
		width: 5%;
	}
	.name{
		
		font-size: 18px;
		margin-left: 20px;
	}
	.each_name{
		padding-top: 10px;
		width: 45%;
	}
	.each_img{
		img{
			height: 80px;
			width: 80px;
			margin-top: 10px;
			margin-left: 5px;
			border-radius: 10px;
		}
		width: 30%;
	}
	.each{
		width: 90%;
		margin-left: 5%;
		height: 100px;
		margin-top: 5%;
		background: white;
		border-radius: 10px;
		display: flex;
	}
	.closeSongList{
		float: right;
		background: #d81e06;
		color: white;
		width: 20%;
		height: 30px;
		font-size: 12px;
	}
	.popup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.phonePopup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.phone-popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.title{
		font-size: 20px;
	}
	.top{
		margin-top: 2%;
		margin-left: 5%;
	}
	.yc{
		color: #bfbfbf;
	}
	.left{
		lable{
			font-size: 18px;
		}
		width: 10%;
		text-align: center;
	}
	.content{
		width: 60%;
	}
	
	.rigt{
		width: 20%;
		line-height: 45px;
		img{
			float: right;
			margin-left: 15%;
		}
	}
	
	.songList{
		display: flex;
		width: 90%;
		background: white;
		margin: 5%;
		border-radius: 10px;
		height: 40px;
		border: 1px solid #ddd;
		border-radius: 10px;
		line-height: 40px;
	}
	.rigt{
		img{
			width: 20px;
			height: 20px;
		}
	}
</style>
