<template>
	<view class="page">
		<view class="content">

			<view class="userback">
				<img :src="userhead">
				<view v-show="flag" class="userName">
					<view class="ljgm_btn" @click='login'>
						授权登录
					</view>
				</view>
				
			</view>

			<view class="cu-list menu-avatar" v-show="flag==false">
				<view class="cu-item" @click="addLocation(1)">
					<view class="content">
						<image src="../../static/icon/loaction.png" mode=""></image>
						<view class="wz">我的足迹</view>
					</view>
				</view>
				<view class="cu-item" @click="rowback">
					<view class="content">
						<image src="../../static/icon/tuichu.png" mode=""></image>
						<view class="wz">退出登录</view>
					</view>
				</view>
			</view>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				userhead: '',
				username: "",
				flag: true,
				modalstatus: false,
				lee: true,
				userId:'',
				noClick:true,
				isType:false,
				lxType:'',
				roleType:''
			}
		},

		methods: {
			rowback(){
				var that = this
				wx.showModal({
					title: '提示',
					content: '确定退出登录吗?',
					showCancel: true,
					confirmText: '确定',
					success: function(res) {
						if (res.confirm) {
							uni.removeStorageSync('userInfo')
							uni.removeStorageSync('phoneNumber')
							
							uni.reLaunch({
								url: '/pages/index/index'
							});
						}
					}
				});
				
			},
			addLocation(){
				uni.navigateTo({
					url:'../myFootprinnt/myFootprinnt',
				});
			}
		},
		onLoad() {
			let that = this;
			uni.checkSession({
					success: (res) => {
					const value = uni.getStorageSync("userInfo");
					if (value != null&&value!="") {
						console.log(value)
						that.userhead = value.data.avatarUrl;
						that.username = value.data.nickName;
						that.userId = value.data.userId;
						that.roleType = value.data.type
						that.flag = false;
						uni.checkSession({
							success: (res) => {
							}
						})
					}
				}
			})
		},

		onShow() {

		},

	}
</script>

<style lang="scss">
	.phone_modal_btn_view{
		view{
			width:100%;
			button{
				width: 100%;
				border: 1px solid green;
				background: green;
				color: white;
				height: 30px;
				line-height: 30px;
			}
			
		}
		display: flex;
	}
	.modal_btn_view{
		view{
			width: 48%;
			button{
				width: 100%;
				border: 1px solid #1296db;
				background: #1296db;
				color: white;
				height: 30px;
				line-height: 30px;
			}
			
		}
		display: flex;
	}
	.popup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.phonePopup {
		position: fixed;
		left: 0;
		right: 0;
		top: 0;
		height: 100vh;
		background-color: rgba(0,0,0,0.6);
		z-index: 9998;
	}
	.phone-popup-info{
		position: fixed;
		width: 700upx;
		top: 40%;
		left: 50%;
		transform: translate(-50%,-50%);
		font-size: 30upx;
		padding: 40upx;
		border-radius: 20upx;
		background-color: #fff;
		z-index: 9999;
	}
	.userback {
		height: 126px;
		background-size: 100%;
		text-align: center;
		margin-top: 10px;
	}

	.userback img {
		margin: auto;
		border-radius: 51px;
		margin-top: 1%;
		width: 97px;
		height: 97px;
	}

	.userName {
		color: #111111;
		font-size: 0.9rem;
	}

	.userOrgan {}

	uni-button[type=primary] {
		margin: 0 4%;
		background-image: linear-gradient(to top, #66b7f9, #1c82d4);
	}

	.cu-list.menu-avatar>.cu-item {
		width: 90%;
		margin-left: 5%;
		margin-top: 2%;
		height: 37px;
		background: white;
		border-radius: 10px;
		border-bottom: 1px solid black;
	}

	.cu-list.menu-avatar>.cu-item .content {

		margin-left: 2%;
		left: 18px;
		float: left;

		margin-top: 10px;
		display: flex;
	}

	.cu-list.menu-avatar>.cu-item .content image {
		width: 20px;
		height: 20px;
	}

	.wz {
		font-size: 18px;
		font-weight: 200;
		margin-left: 5px;
	}

	.cu-list.menu-avatar>.cu-item .jiant {
		margin-left: 2%;
		width: 42px;
		float: right;
		font-size: 18px;
		font-weight: 200;
		margin-top: 10px;
	}

	.cu-list.menu-avatar {
		height: 195px;
	}

	.ljgm_btn {
		width: 90%;
		margin-bottom: 5px;
		margin-top: 1%;
		background: #1296db;
		color: white;
		height: 30px;
		line-height: 30px;
		border-radius: 5px;
	}
</style>
