<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		globalData: {
			//电脑如果切换了网络需要查询一下ip并修改
			url: "http://192.168.101.2:8080/footprint",
			moneyTypeList: [],
			header: {
				'Cookie': ''
			},
			phoneNumber:''
		},
		methods: {
			header() {
				var header = getApp().globalData.header;
				if (header.Cookie == null || header.Cookie == '') {
					const value1 = uni.getStorageSync("userInfo");
					if (value1 != null && value1 != '') {
						getApp().globalData.header.Cookie = 'JSESSIONID=' + value1.data.sessionid;
					}
				}
				return header;
			},
			async login() {
				let that = this;
				return new Promise((resolve, reject) => {
					uni.getProvider({
						service: 'oauth',
						success: function(res) {
							if (~res.provider.indexOf('weixin')) {
								uni.getUserProfile({
									desc: "获取你的昵称、头像、地区及性别",
									success: function(infoRes) {
										uni.setStorage({
											key: 'userInfo',
											data: infoRes,
											success: function() {
											}
										});
										uni.login({
											provider: 'weixin',
											scopes: 'auth_user',
											success: function(loginRes) {
												uni.request({
													url: that.globalData.url + "/user/login",
													data: {
														"userHead": infoRes.userInfo.avatarUrl,
														"userName": infoRes.userInfo.nickName,
														"code": loginRes.code,
														"encryptedData": infoRes.encryptedData,
													},
													method: "GET",
													success: function(result) {
														if(result.data!=null || result.data!=''){
															uni.setStorageSync('userInfo', result);
															that.globalData.header.Cookie = 'JSESSIONID=' + result.data.sessionid;
															console.log(result.data.type)
															uni.switchTab({
																url: '/pages/index/index',
															});
														}
													}	
												})
											}
										});
									},
									fail: function(res) {
										console.log(res)
										wx.showModal({
											title: '警告',
											content: '您拒绝了授权，请重新授权',
											showCancel: false,
											confirmText: '返回授权',
											success: function(res) {
												// 用户没有授权成功，不需要改变 isHide 的值
												if (res.confirm) {
		
												}
											}
										});
									}
								});
							}
						}
					});
				});
			},
			querySession() {
				let that = this;
				var header = this.header();
				return new Promise((resolve, reject) => {
					uni.request({
						url: that.globalData.path + "session/querysession",
						header: header,
						method: "GET",
						success(result) {
							console.log(result);
							if (result.data == -1) {
								console.log(-1);
								uni.showModal({
									content: '登录过期，请重新登录',
									showCancel: false,
								});
								uni.removeStorage({
									key: 'uerInfo',
									success: function(res) {
										setTimeout(function() {
											this.login();
										}, 1000);
									}
								});
								reject('err');
							}
							resolve('suc');
						}
					})
				})
			},
			// 时间转字符串，转成yyyy-MM-dd HH:mm:SS格式
			dateToStr(datetime) {
				var dateTime = new Date(datetime);
				var year = dateTime.getFullYear();
				var month = dateTime.getMonth() + 1; //js从0开始取
				var date = dateTime.getDate();
				var hour = dateTime.getHours();
				var minutes = dateTime.getMinutes();
				var second = dateTime.getSeconds();
				if(month < 10) {
					month = "0" + month;
				}
				if(date < 10) {
					date = "0" + date;
				}
				if(hour < 10) {
					hour = "0" + hour;
				}
				if(minutes < 10) {
					minutes = "0" + minutes;
				}
				if(second < 10) {
					second = "0" + second;
				}
				return year + "-" + month + "-" + date + " " + hour + ":" + minutes + ":" + second;
			},
			// 时间转字符串，转成yyyy-MM-dd格式
			dateToStrNOmm(datetime) {
				var dateTime = new Date(datetime);
				var year = dateTime.getFullYear();
				var month = dateTime.getMonth() + 1; //js从0开始取
				var date = dateTime.getDate();
				var hour = dateTime.getHours();
				var minutes = dateTime.getMinutes();
				var second = dateTime.getSeconds();
			
				if(month < 10) {
					month = "0" + month;
				}
				if(date < 10) {
					date = "0" + date;
				}
				if(hour < 10) {
					hour = "0" + hour;
				}
				if(minutes < 10) {
					minutes = "0" + minutes;
				}
				if(second < 10) {
					second = "0" + second;
				}
			
				return year + "-" + month + "-" + date;
			},
			getPhoneNumber(e) { //点击获取手机号码按钮
				
			},
			
		},
	}
</script>

<style>
	/*每个页面公共css */
</style>
